<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Send an attached mail using php</title>
<link type="text/css" rel="stylesheet" href="css/style.css" media="all" >
</head>
<body>

<h2 align="center"> Main Tutorial <a href="http://www.2my4edge.com/2014/05/send-email-by-using-phpmailer.html"> Send email using phpmailer </a> &nbsp; &nbsp; / &nbsp; &nbsp; More Tutorial <a href="http://www.2my4edge.com">www.2my4edge.com </a> </h2> 

<div class="box">
<h1 align="center">Send mail using PHP Mailer</h1><br>
<form enctype="multipart/form-data" method="post" action="send-mail.php">
<input type="email" name="emailid" class="cmail" autocomplete="off" /> 
<input type="submit" name="submit" class="csubmit" value="Send Mail" />
</form>
</div>
</body>
</html>
