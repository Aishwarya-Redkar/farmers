<div class="mail-box" align="center">
<a href="http://www.2my4edge.com"><img alt="Logo" class="image" src="img/my-logo.png" ></a>
<h1 align="center"> Simple Demo for send mail concept using PHP </h1> 
<h2 align="center"> Check the attachments too </h2>
</div>